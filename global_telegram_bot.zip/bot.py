import asyncio
import logging
import time
import aiosqlite
from aiogram import Bot, Dispatcher, types
from aiogram.enums import ParseMode
from aiogram.filters import CommandStart, Command
from aiogram.types import ReplyKeyboardMarkup, KeyboardButton
from config import *

# Logging setup
logging.basicConfig(level=logging.INFO)

# Initialize bot and dispatcher
bot = Bot(token=BOT_TOKEN, parse_mode=ParseMode.HTML)
dp = Dispatcher()

# Persistent Help button
help_keyboard = ReplyKeyboardMarkup(
    keyboard=[[KeyboardButton(text="Help")]],
    resize_keyboard=True,
    one_time_keyboard=False
)

# Initialize the database
async def init_db():
    async with aiosqlite.connect("users.db") as db:
        await db.execute("""
            CREATE TABLE IF NOT EXISTS users (
                user_id INTEGER PRIMARY KEY,
                balance REAL DEFAULT 0,
                last_bonus INTEGER DEFAULT 0,
                referrals INTEGER DEFAULT 0
            )
        """)
        await db.commit()

# /start command with referral
@dp.message(CommandStart())
async def on_start(message: types.Message):
    user_id = message.from_user.id
    args = message.text.split()
    referrer_id = None
    if len(args) > 1:
        try:
            referrer_id = int(args[1])
        except:
            referrer_id = None

    async with aiosqlite.connect("users.db") as db:
        cursor = await db.execute("SELECT * FROM users WHERE user_id = ?", (user_id,))
        user = await cursor.fetchone()
        if not user:
            await db.execute("INSERT INTO users (user_id, balance, last_bonus, referrals) VALUES (?, ?, ?, ?)",
                             (user_id, JOIN_BONUS, 0, 0))
            await db.commit()
            await message.answer("🎉 Welcome! You received 1 TON as a joining bonus.", reply_markup=help_keyboard)

            if referrer_id and referrer_id != user_id:
                cursor = await db.execute("SELECT balance FROM users WHERE user_id = ?", (referrer_id,))
                ref_user = await cursor.fetchone()
                if ref_user:
                    await db.execute("UPDATE users SET balance = balance + ?, referrals = referrals + 1 WHERE user_id = ?",
                                     (REF_BONUS, referrer_id))
                    await db.commit()
                    try:
                        await bot.send_message(referrer_id, f"👥 You got a referral bonus of {REF_BONUS} TON!")
                    except:
                        pass
        else:
            await message.answer("👋 You already joined. Use /balance to check your TON.", reply_markup=help_keyboard)

# /balance command
@dp.message(Command(commands=["balance"]))
async def check_balance(message: types.Message):
    user_id = message.from_user.id
    async with aiosqlite.connect("users.db") as db:
        cursor = await db.execute("SELECT balance FROM users WHERE user_id = ?", (user_id,))
        user = await cursor.fetchone()
        if user:
            await message.answer(f"💰 Your current balance: <b>{user[0]} TON</b>", reply_markup=help_keyboard)
        else:
            await message.answer("❌ You're not registered. Send /start to join.", reply_markup=help_keyboard)

# /referral command
@dp.message(Command(commands=["referral"]))
async def referral_link(message: types.Message):
    bot_username = (await bot.me()).username
    ref_link = f"https://t.me/{bot_username}?start={message.from_user.id}"
    async with aiosqlite.connect("users.db") as db:
        cursor = await db.execute("SELECT referrals FROM users WHERE user_id = ?", (message.from_user.id,))
        user = await cursor.fetchone()
        referrals = user[0] if user else 0
    await message.answer(f"🔗 Your referral link:\n{ref_link}\n\n👥 Total referrals: {referrals}", reply_markup=help_keyboard)

# /daily command
@dp.message(Command(commands=["daily"]))
async def daily_bonus(message: types.Message):
    user_id = message.from_user.id
    now = int(time.time())
    async with aiosqlite.connect("users.db") as db:
        cursor = await db.execute("SELECT balance, last_bonus FROM users WHERE user_id = ?", (user_id,))
        user = await cursor.fetchone()
        if not user:
            await message.answer("❌ You're not registered. Send /start to join.", reply_markup=help_keyboard)
            return

        last_bonus = user[1]
        if now - last_bonus >= 86400:
            await db.execute("UPDATE users SET balance = balance + ?, last_bonus = ? WHERE user_id = ?",
                             (DAILY_BONUS, now, user_id))
            await db.commit()
            await message.answer(f"🎁 Daily bonus of {DAILY_BONUS} TON claimed!", reply_markup=help_keyboard)
        else:
            remaining = 86400 - (now - last_bonus)
            hours = remaining // 3600
            minutes = (remaining % 3600) // 60
            await message.answer(f"⏳ You can claim your next bonus in {hours}h {minutes}m.", reply_markup=help_keyboard)

# /withdraw command
@dp.message(Command(commands=["withdraw"]))
async def withdraw(message: types.Message):
    user_id = message.from_user.id
    async with aiosqlite.connect("users.db") as db:
        cursor = await db.execute("SELECT balance FROM users WHERE user_id = ?", (user_id,))
        user = await cursor.fetchone()
        if not user:
            await message.answer("❌ You're not registered. Send /start to join.", reply_markup=help_keyboard)
            return

        balance = user[0]
        if balance >= MIN_WITHDRAW:
            await message.answer(f"💸 To withdraw, send your TON wallet address.\n\n"
                                 f"Minimum withdrawal: {MIN_WITHDRAW} TON\n"
                                 f"Deposit address (if required): {WALLET_DEPOSIT_ADDRESS}", reply_markup=help_keyboard)
        else:
            await message.answer(f"⚠️ You need at least {MIN_WITHDRAW} TON to withdraw. Your current balance: {balance} TON.", reply_markup=help_keyboard)

# Help button handler
@dp.message()
async def help_button(message: types.Message):
    if message.text == "Help":
        await message.answer("📖 *Help Guide*:\n/start - Join and get bonus\n/balance - Check your TON balance\n/referral - Get referral link\n/daily - Claim daily bonus\n/withdraw - Withdraw your TON\n/help - Show this help message", parse_mode=ParseMode.MARKDOWN, reply_markup=help_keyboard)

# Start polling
async def main():
    await init_db()
    await dp.start_polling(bot)

if __name__ == "__main__":
    asyncio.run(main())
