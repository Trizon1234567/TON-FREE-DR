import asyncio
import logging
import time
import aiosqlite
from aiogram import Bot, Dispatcher, types
from aiogram.enums import ParseMode
from aiogram.filters import CommandStart, Command
from aiogram.types import ReplyKeyboardMarkup, KeyboardButton
from config import *

# Logging setup
logging.basicConfig(level=logging.INFO)

# Initialize bot and dispatcher
bot = Bot(token=BOT_TOKEN, parse_mode=ParseMode.HTML)
dp = Dispatcher()

# Persistent keyboard with all buttons
main_keyboard = ReplyKeyboardMarkup(
    keyboard=[
        [KeyboardButton(text="Balance"), KeyboardButton(text="Referral")],
        [KeyboardButton(text="Daily"), KeyboardButton(text="Withdraw")],
        [KeyboardButton(text="Help")]
    ],
    resize_keyboard=True,
    one_time_keyboard=False
)

# Initialize the database
async def init_db():
    async with aiosqlite.connect("users.db") as db:
        await db.execute("""
            CREATE TABLE IF NOT EXISTS users (
                user_id INTEGER PRIMARY KEY,
                balance REAL DEFAULT 0,
                last_bonus INTEGER DEFAULT 0,
                referrals INTEGER DEFAULT 0
            )
        """)
        await db.commit()

# /start command with referral
@dp.message(CommandStart())
async def on_start(message: types.Message):
    user_id = message.from_user.id
    args = message.text.split()
    referrer_id = None
    if len(args) > 1:
        try:
            referrer_id = int(args[1])
        except:
            referrer_id = None

    async with aiosqlite.connect("users.db") as db:
        cursor = await db.execute("SELECT * FROM users WHERE user_id = ?", (user_id,))
        user = await cursor.fetchone()
        if not user:
            await db.execute("INSERT INTO users (user_id, balance, last_bonus, referrals) VALUES (?, ?, ?, ?)",
                             (user_id, JOIN_BONUS, 0, 0))
            await db.commit()
            await message.answer("🎉 Welcome! You received 1 TON as a joining bonus.", reply_markup=main_keyboard)

            if referrer_id and referrer_id != user_id:
                cursor = await db.execute("SELECT balance FROM users WHERE user_id = ?", (referrer_id,))
                ref_user = await cursor.fetchone()
                if ref_user:
                    await db.execute("UPDATE users SET balance = balance + ?, referrals = referrals + 1 WHERE user_id = ?",
                                     (REF_BONUS, referrer_id))
                    await db.commit()
                    try:
                        await bot.send_message(referrer_id, f"👥 You got a referral bonus of {REF_BONUS} TON!")
                    except:
                        pass
        else:
            await message.answer("👋 You already joined. Use the menu below.", reply_markup=main_keyboard)

# Button handlers
@dp.message()
async def handle_buttons(message: types.Message):
    text = message.text.lower()
    user_id = message.from_user.id

    if text == "balance":
        async with aiosqlite.connect("users.db") as db:
            cursor = await db.execute("SELECT balance FROM users WHERE user_id = ?", (user_id,))
            user = await cursor.fetchone()
            if user:
                await message.answer(f"💰 Your current balance: <b>{user[0]} TON</b>", reply_markup=main_keyboard)
            else:
                await message.answer("❌ You're not registered. Send /start to join.", reply_markup=main_keyboard)

    elif text == "referral":
        bot_username = (await bot.me()).username
        ref_link = f"https://t.me/{bot_username}?start={user_id}"
        async with aiosqlite.connect("users.db") as db:
            cursor = await db.execute("SELECT referrals FROM users WHERE user_id = ?", (user_id,))
            user = await cursor.fetchone()
            referrals = user[0] if user else 0
        await message.answer(f"🔗 Your referral link:\n{ref_link}\n\n👥 Total referrals: {referrals}", reply_markup=main_keyboard)

    elif text == "daily":
        now = int(time.time())
        async with aiosqlite.connect("users.db") as db:
            cursor = await db.execute("SELECT balance, last_bonus FROM users WHERE user_id = ?", (user_id,))
            user = await cursor.fetchone()
            if not user:
                await message.answer("❌ You're not registered. Send /start to join.", reply_markup=main_keyboard)
                return

            last_bonus = user[1]
            if now - last_bonus >= 86400:
                await db.execute("UPDATE users SET balance = balance + ?, last_bonus = ? WHERE user_id = ?",
                                 (DAILY_BONUS, now, user_id))
                await db.commit()
                await message.answer(f"🎁 Daily bonus of {DAILY_BONUS} TON claimed!", reply_markup=main_keyboard)
            else:
                remaining = 86400 - (now - last_bonus)
                hours = remaining // 3600
                minutes = (remaining % 3600) // 60
                await message.answer(f"⏳ You can claim your next bonus in {hours}h {minutes}m.", reply_markup=main_keyboard)

    elif text == "withdraw":
        async with aiosqlite.connect("users.db") as db:
            cursor = await db.execute("SELECT balance FROM users WHERE user_id = ?", (user_id,))
            user = await cursor.fetchone()
            if not user:
                await message.answer("❌ You're not registered. Send /start to join.", reply_markup=main_keyboard)
                return

            balance = user[0]
            if balance >= MIN_WITHDRAW:
                await message.answer(f"💸 To withdraw, send your TON wallet address.\n\n"
                                     f"Minimum withdrawal: {MIN_WITHDRAW} TON\n"
                                     f"Deposit address (if required): {WALLET_DEPOSIT_ADDRESS}", reply_markup=main_keyboard)
            else:
                await message.answer(f"⚠️ You need at least {MIN_WITHDRAW} TON to withdraw. Your current balance: {balance} TON.", reply_markup=main_keyboard)

    elif text == "help":
        await message.answer("📖 *Help Guide*:\n/start - Join and get bonus\nBalance - Check your TON balance\nReferral - Get referral link\nDaily - Claim daily bonus\nWithdraw - Withdraw your TON", parse_mode=ParseMode.MARKDOWN, reply_markup=main_keyboard)

# Start polling
async def main():
    await init_db()
    await dp.start_polling(bot)

if __name__ == "__main__":
    asyncio.run(main())
